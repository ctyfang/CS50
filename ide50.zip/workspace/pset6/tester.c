#include <stdio.h>
#include <string.h>


int main(void){
    char* word = "test";
    
    char* space = NULL;
    
    space = strchr(word, ' ');

    return 0;
}