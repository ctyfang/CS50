
    Stock: <?= $name ?><br>
    Symbol: <?= $symbol ?><br>
    Price: <?= number_format($price,4) ?><br>



<div>
    <br><br>Go back to the <a href="index.php">Homepage</a>
</div>
