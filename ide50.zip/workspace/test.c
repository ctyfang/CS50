#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(void){
    
    char word[6]= "but\nc\0";
    
    for(int i = 0; i < strlen(word); i++){
        
        printf("%c",word[i]);
    }
    return 0;
    
    
}